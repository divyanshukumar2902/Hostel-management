package com.hostel.management.repository;

import com.hostel.management.entity.AuditLog;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AuditLogRepository extends JpaRepository<AuditLog, Long> {

    List<AuditLog> findTop20ByOrderByCreatedAtDesc();

    Page<AuditLog> findAllByOrderByCreatedAtDesc(Pageable pageable);

    List<AuditLog> findByModuleOrderByCreatedAtDesc(String module);

    List<AuditLog> findByModuleAndRecordIdOrderByCreatedAtAsc(String module, String recordId);

    List<AuditLog> findByModuleAndRecordIdInOrderByCreatedAtAsc(String module, java.util.Collection<String> recordIds);
}
